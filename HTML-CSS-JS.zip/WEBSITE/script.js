// script.js

document.addEventListener('DOMContentLoaded', function() {
    // Function to load gallery images dynamically (simulated with placeholders)
    function loadGalleryImages() {
        const gallery = document.getElementById('gallery');

        // Placeholder URLs for images (replace with actual URLs)
        const imageUrls = [
            'https://via.placeholder.com/400x300',
            'https://via.placeholder.com/400x300',
            'https://via.placeholder.com/400x300'
        ];

        // Generate HTML for gallery items
        imageUrls.forEach(url => {
            const col = document.createElement('div');
            col.classList.add('col');
            col.innerHTML = `
                <div class="card h-100 shadow">
                    <img src="${url}" class="card-img-top" alt="Gallery Image">
                    <div class="card-body">
                        <p class="card-text">Image description.</p>
                    </div>
                </div>
            `;
            gallery.appendChild(col);
        });
    }

    // Call the function to load gallery images
    loadGalleryImages();

    // Example: Submit form handling with animation
    const form = document.getElementById('advancedForm');
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        // Replace with your form submission logic (e.g., AJAX request)
        alert('Form submitted successfully!');
        clearForm();
    });

    // Function to clear form fields
    function clearForm() {
        document.getElementById('name').value = '';
        document.getElementById('email').value = '';
        document.getElementById('message').value = '';
    }
});
